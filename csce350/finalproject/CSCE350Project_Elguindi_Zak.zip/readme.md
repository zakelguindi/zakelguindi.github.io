COMPILATION INSTRUCTIONS
type "make runInputGenerator" to compile the whole program. 
type "make clean" to remove all the .txt files. 
there will be no input files with the submission. they will load when InputFileGenerator is compiled
this program has been extensively tested and runs perfectly when I compile it. If errors occur please email me at ELGUINDI@email.sc.edu 
